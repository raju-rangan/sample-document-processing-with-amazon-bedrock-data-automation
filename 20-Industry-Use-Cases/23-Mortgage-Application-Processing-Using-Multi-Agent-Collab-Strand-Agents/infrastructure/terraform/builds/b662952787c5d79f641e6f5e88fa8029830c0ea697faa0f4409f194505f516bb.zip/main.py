import json
import boto3
import os
from datetime import datetime, timezone
from decimal import Decimal
from typing import Dict, Any, Union, Optional
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ.get('TABLE_NAME', 'mortgage-applications')) # type: ignore

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Main Lambda handler for mortgage applications CRUD operations.
    
    Args:
        event: API Gateway event containing HTTP method, path parameters, query parameters, and body
        context: Lambda context object
        
    Returns:
        HTTP response with statusCode, headers, and JSON body
    """
    try:
        print(event)
        method = event['httpMethod']
        path_params = event.get('pathParameters') or {}
        query_params = event.get('queryStringParameters') or {}
        body = json.loads(event.get('body', '{}')) if event.get('body') else {}
        
        if method == 'POST':
            return create_application(body)
        elif method == 'GET':
            app_id = path_params.get('application_id')
            return get_application(app_id) if app_id else list_applications(query_params)
        elif method == 'PUT':
            return update_application(path_params.get('application_id'), body)
        elif method == 'DELETE':
            return delete_application(path_params.get('application_id'))
        else:
            return response(405, {'error': 'Method not allowed'})
            
    except Exception as e:
        print(f"Error: {str(e)}")
        return response(500, {'error': 'Internal server error'})

def response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create standardized API response with CORS headers.
    
    Args:
        status_code: HTTP status code
        body: Response body to be JSON serialized
        
    Returns:
        Formatted API Gateway response
    """
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body, default=decimal_default)
    }

def decimal_default(obj: Any) -> float:
    """
    JSON serializer for DynamoDB Decimal objects.
    
    Args:
        obj: Object to serialize
        
    Returns:
        Float representation of Decimal
        
    Raises:
        TypeError: If object is not a Decimal
    """
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError

def create_application(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create a new mortgage application in DynamoDB.
    
    Args:
        data: Application data containing required fields:
              application_id, borrower_name, status, application_date
                    
    Returns:
        API response with created application data or error
    """
    required = ['application_id', 'borrower_name', 'status', 'application_date']
    missing = [field for field in required if not data.get(field)]
    if missing:
        return response(400, {'error': f'Missing required fields: {missing}'})
    
    item = {
        **data,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'updated_at': datetime.now(timezone.utc).isoformat()
    }
    
    if 'loan_amount' in item:
        item['loan_amount'] = Decimal(str(item['loan_amount']))
    
    try:
        table.put_item(
            Item=item,
            ConditionExpression='attribute_not_exists(application_id)'
        )
        return response(201, {'message': 'Application created', 'data': item})
    except ClientError as e:
        if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
            return response(409, {'error': 'Application ID already exists'})
        raise

def get_application(app_id: Optional[str]) -> Dict[str, Any]:
    """
    Retrieve a single mortgage application by ID.
    
    Args:
        app_id: Application ID to retrieve
        
    Returns:
        API response with application data or error if not found
    """
    if not app_id:
        return response(400, {'error': 'application_id required'})
    
    try:
        result = table.get_item(Key={'application_id': app_id})
        if 'Item' not in result:
            return response(404, {'error': 'Application not found'})
        return response(200, {'data': result['Item']})
    except ClientError as e:
        print(f"DynamoDB error: {e}")
        return response(500, {'error': 'Database error'})

def list_applications(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    List all mortgage applications with optional pagination.
    
    Args:
        params: Query parameters including limit and last_evaluated_key
                      
    Returns:
        API response with list of all applications and pagination info
    """
    limit = min(int(params.get('limit', 100)), 500)
    
    scan_kwargs = {'Limit': limit}
    
    if params.get('last_evaluated_key'):
        try:
            scan_kwargs['ExclusiveStartKey'] = json.loads(params['last_evaluated_key'])
        except (json.JSONDecodeError, ValueError):
            return response(400, {'error': 'Invalid last_evaluated_key format'})
    
    try:
        result = table.scan(**scan_kwargs)
        
        response_data = {
            'data': result['Items'],
            'count': len(result['Items'])
        }
        
        if 'LastEvaluatedKey' in result:
            response_data['last_evaluated_key'] = json.dumps(result['LastEvaluatedKey'], default=decimal_default)
            response_data['has_more'] = True
        else:
            response_data['has_more'] = False
            
        return response(200, response_data)
    except ClientError as e:
        print(f"Scan error: {e}")
        return response(500, {'error': 'Database error'})

def update_application(app_id: Optional[str], data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Update an existing mortgage application.
    
    Args:
        app_id: Application ID to update
        data: Fields to update (excluding application_id)
        
    Returns:
        API response with updated application data or error
    """
    if not app_id:
        return response(400, {'error': 'application_id required'})
    
    if not data:
        return response(400, {'error': 'Update data required'})
    
    update_expr = 'SET updated_at = :updated_at'
    attr_values = {':updated_at': datetime.now(timezone.utc).isoformat()}
    attr_names = {}
    
    for key, value in data.items():
        if key != 'application_id':
            safe_key = f'#{key}'
            value_key = f':{key}'
            update_expr += f', {safe_key} = {value_key}'
            attr_names[safe_key] = key
            attr_values[value_key] = Decimal(str(value)) if key == 'loan_amount' else value
    
    try:
        result = table.update_item(
            Key={'application_id': app_id},
            UpdateExpression=update_expr,
            ExpressionAttributeNames=attr_names,
            ExpressionAttributeValues=attr_values,
            ConditionExpression='attribute_exists(application_id)',
            ReturnValues='ALL_NEW'
        )
        return response(200, {'message': 'Application updated', 'data': result['Attributes']})
    except ClientError as e:
        if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
            return response(404, {'error': 'Application not found'})
        print(f"Update error: {e}")
        return response(500, {'error': 'Database error'})

def delete_application(app_id: Optional[str]) -> Dict[str, Any]:
    """
    Delete a mortgage application from DynamoDB.
    
    Args:
        app_id: Application ID to delete
        
    Returns:
        API response with deleted application data or error if not found
    """
    if not app_id:
        return response(400, {'error': 'application_id required'})
    
    try:
        result = table.delete_item(
            Key={'application_id': app_id},
            ConditionExpression='attribute_exists(application_id)',
            ReturnValues='ALL_OLD'
        )
        if 'Attributes' not in result:
            return response(404, {'error': 'Application not found'})
        return response(200, {'message': 'Application deleted', 'data': result['Attributes']})
    except ClientError as e:
        if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
            return response(404, {'error': 'Application not found'})
        print(f"Delete error: {e}")
        return response(500, {'error': 'Database error'})