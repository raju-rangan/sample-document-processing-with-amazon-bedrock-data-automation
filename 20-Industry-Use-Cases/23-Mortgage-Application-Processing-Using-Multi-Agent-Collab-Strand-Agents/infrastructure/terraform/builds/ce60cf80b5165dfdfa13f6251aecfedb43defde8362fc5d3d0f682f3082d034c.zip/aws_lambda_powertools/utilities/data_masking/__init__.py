from aws_lambda_powertools.utilities.data_masking.base import DataMasking

__all__ = [
    "DataMasking",
]
