import json
from typing import Dict, Any
from aws_lambda_powertools import Logger
from aws_lambda_powertools.utilities.typing import LambdaContext



logger = Logger(service="mortgage-preprocess-service")


@logger.inject_lambda_context(log_event=True)
def lambda_handler(event: Dict[str, Any], context: LambdaContext) -> Dict[str, Any]:
    """
    Lambda function to handle S3 events when new objects are added.
    
    Args:
        event: S3 event data containing Records with bucket and object information
        context: Lambda context object
    
    Returns:
        Dict containing processing results
    """
    try:
        processed_objects = []
        
        for record in event.get('Records', []):
            if record.get('eventSource') == 'aws:s3':
                s3_info = record.get('s3', {})
                bucket_name = s3_info.get('bucket', {}).get('name')
                object_key = s3_info.get('object', {}).get('key')
                object_size = s3_info.get('object', {}).get('size', 0)
                event_name = record.get('eventName', '')
                
                logger.info(
                    f"Processing S3 event",
                    extra={
                        "event_name": event_name,
                        "bucket_name": bucket_name,
                        "object_key": object_key,
                        "object_size": object_size
                    }
                )

                if event_name.startswith('ObjectCreated'):
                    processed_objects.append(object_key)
                else:
                    logger.info(f"Skipping non-creation event: {event_name}")
        return response(200, {'message': 'request accepted', 'objects': processed_objects})
        
    except Exception as e:
        logger.error(f"Error processing S3 event: {str(e)}", exc_info=True)
        return response(500, {"error": "Failed to process S3 event", 'message': str(e)})

def response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(body, default=str),
    }