"""Exposes version constant to avoid circular dependencies."""

VERSION = "3.19.0"
